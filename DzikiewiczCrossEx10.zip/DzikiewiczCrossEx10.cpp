/*******************************************************************
SUNY Broome Community College
CST 133 - Exercise 10
Cross Dzikiewicz
********************************************************************/

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

// Constants
const int MAX = 15;
const int POSITIONS = 9;
const int IGNORE = 100;

// Struct
struct playerRecord
{
    string name;
    string position;
    int number = 0;
    int atBats = 0;
    int hits = 0;
    int basesTaken = 0;
    int ranking = 0;
    double battingAverage = 0;
    double sluggingAverage = 0;
};

// Function Prototypes

// Task 1 - InputPlayerData
void InputPlayerData(ifstream& fin, playerRecord player[], int& numOfPlayers);

// Task 2 - CalculateBattingAverage
double CalculateBattingAverage(int hits, int atBats);

// Task 3 - CalculateSluggingAverage
double CalculateSluggingAverage(int basesTaken, int atBats);

// Task 4 - CalculateAverages
void CalculateAverages(playerRecord player[], int numOfPlayers);

// Task 5 - InitializeRanking
void InitializeRanking(playerRecord player[], int numOfPlayers);

// Task 6 - CalculateRanking
void CalculateRanking(playerRecord player[], int numOfPlayers);

// Task 7 - OutputPlayerData
void OutputPlayerData(ofstream& fout, playerRecord player[], int numOfPlayers);

// Task 8 - OutputOverHits
void OutputOverHits(ofstream& fout, playerRecord player[],
    int numOfPlayers, int hitsValue);

// Task 9 - InputPlayerPosition
void InputPlayerPosition(ifstream& finPos, string playerPosition[]);

// Task 10 - OutputPlayerByPosition
void OutputPlayerByPosition(ofstream& fout, playerRecord player[],
    int numOfPlayers, string playerPosition[]);

// Task 11 - Swap
void Swap(playerRecord& item1, playerRecord& item2);

// Task 12 - IndexOfSmallest
int IndexOfSmallest(playerRecord player[], int startIndex, int numOfPlayers);

// Task 13 - SelectionSort
void SelectionSort(playerRecord player[], int numOfPlayers);

// Task 14 - OutputPlayerByNumber
void OutputPlayerByNumber(ofstream& fout, playerRecord player[],
    int numOfPlayers);

// Support Functions
void OutputDivider(ofstream& fout, char symbol, int amount);
void OutputHeading(ofstream& fout);

//Main Function
int main()
{
    ifstream fin;
    ifstream finPos;
    ofstream fout;

    playerRecord player[MAX];
    string playerPosition[POSITIONS];

    // Tag Field
    int numOfPlayers = 0;

    // Open Files
    fin.open("SoftballData.txt");
    finPos.open("PlayerPos.txt");
    fout.open("SoftballResults.txt");

    // Precision
    fout << fixed << setprecision(3);

    // OutputHeading
    OutputHeading(fout);

    //OutputDivider
    OutputDivider(fout, '-', 90);

    // Task 1 - InputPlayerData
    InputPlayerData(fin, player, numOfPlayers);

    // Task 4 - CalculateAverages
    CalculateAverages(player, numOfPlayers);

    // Task 5 - InitializeRanking
    InitializeRanking(player, numOfPlayers);

    // Task 6 - CalculateRanking
    CalculateRanking(player, numOfPlayers);

    // Task 7 - OutputPlayerData
    OutputPlayerData(fout, player, numOfPlayers);

    // Task 8 - OutputOverHits (20)
    OutputOverHits(fout, player, numOfPlayers, 20);

    // Task 8 - OutputOverHits (10)
    OutputOverHits(fout, player, numOfPlayers, 10);

    // Task 9 - InputPlayerPosition
    InputPlayerPosition(finPos, playerPosition);

    // Task 10 - OutputPlayerByPosition
    OutputPlayerByPosition(fout, player, numOfPlayers, playerPosition);

    // Task 13 - SelectionSort
    SelectionSort(player, numOfPlayers);

    // Task 14 - OutputPlayerByNumber
    OutputPlayerByNumber(fout, player, numOfPlayers);

    // Close Files
    fin.close();
    finPos.close();
    fout.close();

    return 0;
}

// Task 1 - InputPlayerData
void InputPlayerData(ifstream& fin, playerRecord player[], int& numOfPlayers)
{
    // Priming Read
    getline(fin, player[numOfPlayers].name);

    while (!fin.eof() && numOfPlayers < MAX)
    {
        getline(fin, player[numOfPlayers].position);

        fin >> player[numOfPlayers].number;
        fin >> player[numOfPlayers].atBats;
        fin >> player[numOfPlayers].hits;
        fin >> player[numOfPlayers].basesTaken;

        fin.ignore(IGNORE, '\n');

        numOfPlayers++;

        getline(fin, player[numOfPlayers].name);
    }
}

// Task 2 - CalculateBattingAverage
double CalculateBattingAverage(int hits, int atBats)
{
    if (atBats == 0)
        return 0.0;
    return (double)hits / atBats;
}

// Task 3 - CalculateSluggingAverage
double CalculateSluggingAverage(int basesTaken, int atBats)
{
    if (atBats == 0)
        return 0.0;
    return (double)basesTaken / atBats;
}

// Task 4 - CalculateAverages
void CalculateAverages(playerRecord player[], int numOfPlayers)
{
    for (int i = 0; i < numOfPlayers; i++)
    {
        player[i].battingAverage =
            CalculateBattingAverage(player[i].hits, player[i].atBats);

        player[i].sluggingAverage =
            CalculateSluggingAverage(player[i].basesTaken, player[i].atBats);
    }
}

// Task 5 - InitializeRanking
void InitializeRanking(playerRecord player[], int numOfPlayers)
{
    for (int i = 0; i < numOfPlayers; i++)
    {
        player[i].ranking = 0;
    }
}

// Task 6 - CalculateRanking
void CalculateRanking(playerRecord player[], int numOfPlayers)
{
    int rankingsSet = 0;
    int currentRank = 1;

    while (rankingsSet < numOfPlayers)
    {
        double highestAverage = 0.0;
        int highestIndex = -1;

        for (int i = 0; i < numOfPlayers; i++)
        {
            if (player[i].battingAverage > highestAverage
                && player[i].ranking == 0)
            {
                highestAverage = player[i].battingAverage;
                highestIndex = i;
            }
        }

        player[highestIndex].ranking = currentRank;

        currentRank++;
        rankingsSet++;
    }
}

// Task 7 - OutputPlayerData
void OutputPlayerData(ofstream& fout, playerRecord player[],
    int numOfPlayers)
{
    fout << left << setw(22) << "Player"
        << right << setw(5) << "#"
        << setw(15) << "Position"
        << setw(6) << "AB"
        << setw(6) << "H"
        << setw(6) << "BT"
        << setw(10) << "BA"
        << setw(10) << "SLG%"
        << setw(8) << "Rank" << endl;

    OutputDivider(fout, '-', 90);

    for (int i = 0; i < numOfPlayers; i++)
    {
        fout << left << setw(22) << player[i].name
            << right << setw(5) << player[i].number
            << setw(15) << player[i].position
            << setw(6) << player[i].atBats
            << setw(6) << player[i].hits
            << setw(6) << player[i].basesTaken
            << setw(10) << player[i].battingAverage
            << setw(10) << player[i].sluggingAverage
            << setw(8) << player[i].ranking << endl;
    }

    OutputDivider(fout, '-', 90);
}

// Task 8 - OutputOverHits
void OutputOverHits(ofstream& fout, playerRecord player[],
    int numOfPlayers, int hitsValue)
{
    int count = 0;

    fout << "These players had more than "
        << hitsValue << " hits" << endl;

    fout << left << setw(25) << "Name"
        << right << setw(6) << "Hits" << endl;

    OutputDivider(fout, '-', 60);

    for (int i = 0; i < numOfPlayers; i++)
    {
        if (player[i].hits > hitsValue)
        {
            fout << left << setw(25) << player[i].name
                << right << setw(6) << player[i].hits << endl;
            count++;
        }
    }

    if (count == 0)
    {
        fout << "No players had hits over "
            << hitsValue << "." << endl;
    }
    else
    {
        fout << "The number of players who had hits over "
            << hitsValue << " is " << count << endl;
    }

    OutputDivider(fout, '-', 60);
}

// Task 9 - InputPlayerPosition
void InputPlayerPosition(ifstream& finPos, string playerPosition[])
{
    for (int i = 0; i < POSITIONS; i++)
    {
        getline(finPos, playerPosition[i]);
    }
}

// Task 10 - OutputPlayerByPosition
void OutputPlayerByPosition(ofstream& fout, playerRecord player[],
    int numOfPlayers, string playerPosition[])
{
    fout << "Players By Position" << endl;

    OutputDivider(fout, '-', 60);

    fout << left << setw(25) << "Name"
        << setw(20) << "Position"
        << setw(10) << "Number" << endl;

    OutputDivider(fout, '-', 60);

    for (int i = 0; i < POSITIONS; i++)
    {
        for (int j = 0; j < numOfPlayers; j++)
        {
            if (player[j].position == playerPosition[i])
            {
                fout << left << setw(25) << player[j].name
                    << setw(20) << player[j].position
                    << setw(10) << player[j].number << endl;
            }
        }
    }

    OutputDivider(fout, '-', 60);
}

// Task 11 - Swap
void Swap(playerRecord& item1, playerRecord& item2)
{
    playerRecord temp = item1;
    item1 = item2;
    item2 = temp;
}

// Task 12 - IndexOfSmallest
int IndexOfSmallest(playerRecord player[],
    int startIndex, int numOfPlayers)
{
    int minIndex = startIndex;

    for (int index = startIndex + 1;
        index < numOfPlayers; index++)
    {
        if (player[index].number <
            player[minIndex].number)
        {
            minIndex = index;
        }
    }

    return minIndex;
}

// Task 13 - SelectionSort
void SelectionSort(playerRecord player[], int numOfPlayers)
{
    int minIndex;

    for (int index = 0;
        index < numOfPlayers - 1; index++)
    {
        minIndex =
            IndexOfSmallest(player, index, numOfPlayers);

        Swap(player[minIndex], player[index]);
    }
}

// Task 14 - OutputPlayerByNumber
void OutputPlayerByNumber(ofstream& fout, playerRecord player[],
    int numOfPlayers)
{
    fout << "Players By Jersey Number" << endl;

    OutputDivider(fout, '-', 50);

    fout << left << setw(25) << "Name"
        << setw(10) << "Number" << endl;

    OutputDivider(fout, '-', 50);

    for (int i = 0; i < numOfPlayers; i++)
    {
        fout << left << setw(25) << player[i].name
            << setw(10) << player[i].number << endl;
    }

    OutputDivider(fout, '-', 50);
}

// utility - OutputDivider
void OutputDivider(ofstream& fout, char ch, int amount)
{
    for (int i = 0; i < amount; i++)
    {
        fout << ch;
    }
    fout << endl;
}

// Utility - OutputHeading
void OutputHeading(ofstream& fout)
{
    fout << "SUNY Broome Community College" << endl;
    fout << "Cross Dzikiewicz" << endl;
    fout << "CST 133 - Exercise 10" << endl;
}